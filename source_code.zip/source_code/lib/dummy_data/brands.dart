class Brand {
  String id;
  String image;
  String name;

  Brand({this.id,this.image, this.name,});
}

final List<Brand> dummyBrandList = [
  Brand(id:"1",image: "dummy_assets/b1.jpeg", name: "Apple"),
  Brand(id:"2",image: "dummy_assets/b2.jpeg", name: "BMW"),
  Brand(id:"3",image: "dummy_assets/b3.jpeg", name: "Ford",),
  Brand(id:"4",image: "dummy_assets/b4.jpeg", name: "HP"),
  Brand(id:"5",image: "dummy_assets/b5.jpeg", name: "Nike"),
  Brand(id:"6",image: "dummy_assets/b6.jpeg", name: "Nissan"),
  Brand(id:"7",image: "dummy_assets/b7.jpeg", name: "Omega"),
  Brand(id:"8",image: "dummy_assets/b8.jpeg", name: "Puma"),
  Brand(id:"9",image: "dummy_assets/b9.jpeg", name: "Rolex"),
  Brand(id:"10",image: "dummy_assets/b10.jpeg", name: "Yamaha"),
];
